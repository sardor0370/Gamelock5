package uz.gamelock

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class LockService : AccessibilityService() {

    companion object {
        @Volatile var instance: LockService? = null
    }

    private val edges = mutableListOf<View>()

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hideEdges()
        instance = null
        return super.onUnbind(intent)
    }

    /**
     * Faqat kerakli joyga ko'rinmas to'siq qo'yadi (Home/Recents tugmalari yoki surish joyi).
     * Pastki chet va yon chetlar kengligi ilovada sozlanadi; yuqori chet to'silmaydi.
     */
    fun showEdges() {
        hideEdges()
        val sp = getSharedPreferences("gl", MODE_PRIVATE)
        val top = sp.getInt("top", 0)
        val bottom = sp.getInt("bottom", 0)
        val side = sp.getInt("side", 0)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density

        fun add(gravity: Int, widthPx: Int, heightPx: Int) {
            val v = View(this)
            v.setOnTouchListener { _, _ -> true }
            val lp = WindowManager.LayoutParams(
                widthPx,
                heightPx,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = gravity
            try {
                wm.addView(v, lp)
                edges.add(v)
            } catch (_: Exception) { }
        }

        if (top > 0) {
            add(Gravity.TOP, WindowManager.LayoutParams.MATCH_PARENT, (top * density).toInt())
        }
        if (bottom > 0) {
            add(Gravity.BOTTOM, WindowManager.LayoutParams.MATCH_PARENT, (bottom * density).toInt())
        }
        if (side > 0) {
            val w = (side * density).toInt()
            add(Gravity.LEFT, w, WindowManager.LayoutParams.MATCH_PARENT)
            add(Gravity.RIGHT, w, WindowManager.LayoutParams.MATCH_PARENT)
        }
    }

    fun hideEdges() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        for (v in edges) {
            try { wm.removeView(v) } catch (_: Exception) { }
        }
        edges.clear()
    }

    private val handler = Handler(Looper.getMainLooper())
    private var upDown = false
    private var downDown = false
    private var lastLaunch = 0L
    private var lastShade = 0L

    // ---------- Tizim mahkamlashi (Pin) ----------
    private var pinTries = 0
    private var lastLabelClick = -10
    private var pinLabel = ""
    private val pinKeys = listOf(
        "pin this app", "pin app", "pin window", "pin screen", "screen pinning",
        "mahkamla", "закреп", "прикреп"
    )
    private val okKeys = listOf("start", "got it", "ok", "boshlash", "tushunarli", "понятно", "начать", "yes")

    private fun isPinned(): Boolean {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        return am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
    }

    /** Recents'ni ochib, o'yin kartochkasidagi "Pin" tugmasini o'zi bosadi. */
    fun startPin(label: String) {
        if (!LockState.locked) return
        pinLabel = label.lowercase().trim()
        pinTries = 0
        lastLabelClick = -10
        LockState.pinning = true
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed(pinStep, 1000)
    }

    private val pinStep = object : Runnable {
        override fun run() {
            if (!LockState.locked || !LockState.pinning) return
            pinTries++
            if (isPinned()) { finishPin(true); return }
            val root = rootInActiveWindow
            if (root != null) {
                var acted = false
                val ok = findNode(root, okKeys, false, 0)
                if (ok != null && clickNode(ok)) acted = true
                if (!acted) {
                    val pin = findNode(root, pinKeys, true, 0)
                    if (pin != null && clickNode(pin)) acted = true
                }
                if (!acted && pinLabel.isNotEmpty() && pinTries - lastLabelClick >= 3) {
                    val icon = findNode(root, listOf(pinLabel), false, 0)
                    if (icon != null && clickNode(icon)) lastLabelClick = pinTries
                }
            }
            if (pinTries >= 14) { finishPin(false); return }
            handler.postDelayed(this, 700)
        }
    }

    private fun finishPin(success: Boolean) {
        LockState.pinning = false
        if (success) {
            LockState.pinned = true
            Toast.makeText(this, "Mahkamlandi", Toast.LENGTH_SHORT).show()
            handler.postDelayed(watchPin, 1500)
        } else {
            Toast.makeText(
                this,
                "Avtomatik mahkamlab bo'lmadi. Qo'lda: Recents → ilova belgisi → Pin. Hozircha oddiy qulf ishlaydi.",
                Toast.LENGTH_LONG
            ).show()
            val intent = packageManager.getLaunchIntentForPackage(LockState.target)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                startActivity(intent)
            }
        }
    }

    // Foydalanuvchi tizim usuli bilan mahkamlashdan chiqsa, qulfni ham tugatamiz
    private val watchPin = object : Runnable {
        override fun run() {
            if (!LockState.locked || !LockState.pinned) return
            if (!isPinned()) {
                unlockNow()
                return
            }
            handler.postDelayed(this, 1000)
        }
    }

    private fun findNode(n: AccessibilityNodeInfo?, keys: List<String>, contains: Boolean, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 25) return null
        val texts = listOfNotNull(n.text?.toString(), n.contentDescription?.toString()).map { it.lowercase().trim() }
        if (texts.any { t -> keys.any { k -> if (contains) t.contains(k) else t == k } }) return n
        for (i in 0 until n.childCount) {
            val r = findNode(n.getChild(i), keys, contains, depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var d = 0
        while (cur != null && d < 6) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
            d++
        }
        return false
    }

    // Bildirishnoma paneli / boshqaruv markazi oynalarining taxminiy nomlari
    private val shadeHints = listOf(
        "shade", "notificationpanel", "controlcenter", "quicksetting", "qspanel", "notificationcenter"
    )

    private fun closeShade() {
        if (Build.VERSION.SDK_INT >= 31) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        } else {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    // Shu ilovalar oynasi ochilsa, o'yinga qaytarmaymiz
    private val keep = setOf(
        "com.android.systemui",
        "android",
        "com.google.android.gms",
        "com.samsung.android.honeyboard",
        "com.google.android.inputmethod.latin",
        "com.samsung.android.game.gametools"
    )

    private val unlockRunnable = Runnable {
        if (LockState.locked && upDown && downDown) unlockNow()
    }

    private fun unlockNow() {
        LockState.unlock(this)
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) { }
        val still = try { isPinned() } catch (_: Exception) { false }
        Toast.makeText(
            this,
            if (still) "Qulf ochildi. Mahkamlashni Orqaga + Recents ni ushlab oching" else "Qulf ochildi",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!LockState.locked) {
            upDown = false
            downDown = false
            return false
        }
        val code = event.keyCode

        // Home va Recents tugmalarini bloklaymiz (ekranga tegmasdan): hodisani yutib yuboramiz
        if (code == KeyEvent.KEYCODE_HOME || code == KeyEvent.KEYCODE_APP_SWITCH) return true

        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        // tugma ushlab turilganda takrorlanuvchi hodisalarni e'tiborsiz qoldiramiz
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount > 0) return false

        val down = event.action == KeyEvent.ACTION_DOWN
        if (code == KeyEvent.KEYCODE_VOLUME_UP) upDown = down else downDown = down

        handler.removeCallbacks(unlockRunnable)
        if (upDown && downDown) handler.postDelayed(unlockRunnable, 3000)
        return false // ovoz balandligi odatdagidek o'zgaradi
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!LockState.locked) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        LockState.note("$pkg / ${event.className}")
        if (LockState.pinning || LockState.pinned) return

        if (pkg == "com.android.systemui") {
            val cn = event.className?.toString()?.lowercase() ?: ""
            if (shadeHints.any { cn.contains(it) }) {
                val t = SystemClock.elapsedRealtime()
                if (t - lastShade > 300) {
                    lastShade = t
                    closeShade()
                }
            }
            return
        }
        if (pkg == LockState.target || pkg == packageName || pkg in keep) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastLaunch < 500) return
        lastLaunch = now

        val intent = packageManager.getLaunchIntentForPackage(LockState.target)
        if (intent == null) {
            unlockNow() // o'yin topilmasa, qulfda qolib ketmaslik uchun
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        startActivity(intent)
    }

    override fun onInterrupt() {}
}
